export const DateUtil = {
    to_date: (date_str) => {
        let yyyyMMdd = String(date_str);
        let sYear = yyyyMMdd.substring(0, 4);
        let sMonth = yyyyMMdd.substring(4, 6);
        let sDate = yyyyMMdd.substring(6, 8);
        let sHours = yyyyMMdd.substring(8, 10);
        let sMinutes = yyyyMMdd.substring(10, 12);
        let sSeconds = yyyyMMdd.substring(10, 14);

        return new Date(
            Number(sYear),
            Number(sMonth) - 1,
            Number(sDate),
            Number(sHours),
            Number(sMinutes),
            Number(sSeconds),
        );
    },

    to_date_format: (date_str, gubun) => {
        let yyyyMMdd = String(date_str);
        let sYear = yyyyMMdd.substring(0, 4);
        let sMonth = yyyyMMdd.substring(4, 6);
        let sDate = yyyyMMdd.substring(6, 8);

        return sYear + gubun + sMonth + gubun + sDate;
    },

    get_date_str: (date) => {
        let sYear = date.getFullYear();
        let sMonth = date.getMonth() + 1;
        let sDate = date.getDate();
        let sHours = date.getHours();
        let sMinutes = date.getMinutes();
        let sSeconds = date.getSeconds();

        sMonth = sMonth > 9 ? sMonth : '0' + sMonth;
        sDate = sDate > 9 ? sDate : '0' + sDate;
        sHours = sHours > 9 ? sHours : '0' + sHours;
        sMinutes = sMinutes > 9 ? sMinutes : '0' + sMinutes;
        sSeconds = sSeconds > 9 ? sSeconds : '0' + sSeconds;
        return sYear.toString() + sMonth.toString() + sDate.toString() + sHours.toString() + sMinutes.toString() + sSeconds.toString();
    },
};
