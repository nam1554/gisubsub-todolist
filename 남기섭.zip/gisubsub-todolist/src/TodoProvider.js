import React, { useReducer, createContext, useContext, useRef } from 'react';
import CryptoJS from 'crypto-js';

const initialTodos = {
    todos: localStorage.getItem('todos')
        ? JSON.parse(
              CryptoJS.AES.decrypt(
                  localStorage.getItem('todos'),
                  'gisubsub-todoList'
              ).toString(CryptoJS.enc.Utf8)
          )
        : [],
    filter: '0',
    modalState: {
        visible: false,
        closable: true,
        maskClosable: true,
        modalContent: undefined,
        onClose: undefined,
    },
};

const nextIdCurrent = localStorage.getItem('nextIdCurrent')
    ? Number(JSON.parse(localStorage.getItem('nextIdCurrent')))
    : 0;

function todoReducer(state, action) {
    let newTodos;
    switch (action.type) {
        case 'CREATE':
            newTodos = state.todos.concat(action.todo);
            localStorage.setItem(
                'todos',
                CryptoJS.AES.encrypt(
                    JSON.stringify(newTodos),
                    'gisubsub-todoList'
                ).toString()
            );
            localStorage.setItem(
                'nextIdCurrent',
                JSON.stringify(action.todo.id)
            );
            return {
                ...state,
                todos: newTodos,
            };
        case 'TOGGLE':
            newTodos = state.todos.map((todo) =>
                todo.id === action.id ? { ...todo, done: !todo.done } : todo
            );
            localStorage.setItem(
                'todos',
                CryptoJS.AES.encrypt(
                    JSON.stringify(newTodos),
                    'gisubsub-todoList'
                ).toString()
            );
            return {
                ...state,
                todos: newTodos,
            };
        case 'REMOVE':
            newTodos = state.todos.filter((todo) => todo.id !== action.id);
            localStorage.setItem(
                'todos',
                CryptoJS.AES.encrypt(
                    JSON.stringify(newTodos),
                    'gisubsub-todoList'
                ).toString()
            );
            return {
                ...state,
                todos: newTodos,
            };
        case 'FILTER':
            return {
                ...state,
                filter: action.filter,
            };
        case 'MODALSET':
            return {
                ...state,
                modalState: action.modalState,
            };
        default:
            throw new Error(`Unhandled action type: ${action.type}`);
    }
}

const TodoStateContext = createContext();
const TodoDispatchContext = createContext();
const TodoNextIdContext = createContext();

export function TodoProvider({ children }) {
    const [state, dispatch] = useReducer(todoReducer, initialTodos);
    const nextId = useRef(nextIdCurrent + 1);

    return (
        <TodoStateContext.Provider value={state}>
            <TodoDispatchContext.Provider value={dispatch}>
                <TodoNextIdContext.Provider value={nextId}>
                    {children}
                </TodoNextIdContext.Provider>
            </TodoDispatchContext.Provider>
        </TodoStateContext.Provider>
    );
}

export function useTodoState() {
    const context = useContext(TodoStateContext);
    if (!context) {
        throw new Error('Cannot find TodoProvider');
    }
    return context;
}

export function useTodoDispatch() {
    const context = useContext(TodoDispatchContext);
    if (!context) {
        throw new Error('Cannot find TodoProvider');
    }
    return context;
}

export function useTodoNextId() {
    const context = useContext(TodoNextIdContext);
    if (!context) {
        throw new Error('Cannot find TodoProvider');
    }
    return context;
}
