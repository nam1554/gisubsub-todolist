import React, { useState } from 'react';
import styled, { css } from 'styled-components';
import { useTodoState, useTodoDispatch } from '../TodoProvider';

const TodoHeadBlock = styled.div`
    padding-top: 48px;
    padding-left: 32px;
    padding-right: 32px;
    padding-bottom: 24px;
    border-bottom: 1px solid #e9ecef;
    h1 {
        margin: 0;
        font-size: 36px;
        color: #343a40;
    }
    .day {
        margin-top: 4px;
        color: #868e96;
        font-size: 21px;
    }
    .tasks-container {
        display: flex;
    }
    .tasks-left {
        flex: 7;
        color: #20c997;
        font-size: 18px;
        margin-top: 40px;
        font-weight: bold;
    }
    .tasks-right {
        display: flex;
        flex: 4;
        color: #ced4da;
        font-size: 12px;
        margin-top: 40px;
        font-weight: bold;
    }
`;

const TodoFilterDiv = styled.div`
    margin-left: 3px;
    margin-right: 3px;
    cursor: pointer;
    color: #ced4da;
    ${(props) =>
        props.clicked &&
        css`
            color: #20c997;
        `}
`;

function TodoHead() {
    const { todos, filter } = useTodoState();
    const [clicked, setClicked] = useState(
        [true, false, false].map((item, index) => Number(filter) === index)
    );
    const undoneTasks = todos.filter((todo) => !todo.done);

    const dispatch = useTodoDispatch();

    const onFilter = (filter) => {
        setClicked(clicked.map((item, index) => Number(filter) === index));
        dispatch({
            type: 'FILTER',
            filter: filter,
        });
    };

    const today = new Date();
    const dateString = today.toLocaleDateString('ko-KR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
    });
    const dayName = today.toLocaleDateString('ko-KR', { weekday: 'long' });

    return (
        <TodoHeadBlock>
            <h1>{dateString}</h1>
            <div className="day">{dayName}</div>
            <div className="tasks-container">
                <div className="tasks-left">
                    할 일 {undoneTasks.length}개 남음
                </div>
                <div className="tasks-right">
                    <TodoFilterDiv
                        clicked={clicked[0]}
                        onClick={() => {
                            onFilter('0');
                        }}
                    >
                        ALL
                    </TodoFilterDiv>
                    |
                    <TodoFilterDiv
                        clicked={clicked[1]}
                        onClick={() => {
                            onFilter('1');
                        }}
                    >
                        DONE
                    </TodoFilterDiv>
                    |
                    <TodoFilterDiv
                        clicked={clicked[2]}
                        onClick={() => {
                            onFilter('2');
                        }}
                    >
                        NOT DONE
                    </TodoFilterDiv>
                </div>
            </div>
        </TodoHeadBlock>
    );
}

export default React.memo(TodoHead);
