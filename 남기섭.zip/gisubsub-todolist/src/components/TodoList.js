import React from 'react';
import styled from 'styled-components';
import { useTodoState } from '../TodoProvider';
import TodoItem from './TodoItem';

const TodoListBlock = styled.div`
    flex: 1;
    padding: 20px 32px;
    padding-bottom: 48px;
    overflow-y: auto;
`;

function TodoList() {
    const { todos, filter } = useTodoState();

    let filterObj = (todo) => {
        if (filter === '1') {
            return todo.done;
        } else if (filter === '2') {
            return !todo.done;
        } else {
            return todo;
        }
    };

    todos.sort((a, b) => {
        if (!a.done && b.done) return -1;
        if (a.done && !b.done) return 1;
        return Number(b.createDate) - Number(a.createDate);
    });

    return (
        <TodoListBlock>
            {todos.filter(filterObj).map((todo) => (
                <TodoItem
                    key={todo.id}
                    id={todo.id}
                    text={todo.text}
                    arrText={todo.arrText}
                    done={todo.done}
                    createDate={todo.createDate}
                />
            ))}
        </TodoListBlock>
    );
}

export default TodoList;
